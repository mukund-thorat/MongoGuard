# MongoGuard

A simple, optimistic, and efficient CRUD layer for MongoDB.

## Installation
```bash
pip install mongoguard
